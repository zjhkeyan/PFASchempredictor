#  Copyright (c) Prior Labs GmbH 2026.

"""Settings module for TabPFN configuration."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import torch
from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

from tabpfn.constants import ModelVersion


class TabPFNSettings(BaseSettings):
    """Configuration settings for TabPFN.

    These settings can be configured via environment variables or a .env file.

    Prefixed by ``TABPFN_`` in environment variables.
    """

    # Set extra="ignore" so that unknown keys in the .env file, for example, entries for
    # other applications, do not cause validation errors.
    model_config = SettingsConfigDict(
        env_prefix="TABPFN_", env_file=".env", extra="ignore"
    )

    # Model Configuration
    model_cache_dir: Path | None = Field(
        default=None,
        description="Custom directory for caching downloaded TabPFN models. "
        "If not set, uses platform-specific user cache directory.",
    )
    model_version: ModelVersion = Field(
        default=ModelVersion.V3_5,
        description="The version of the TabPFN model to use by default.",
    )

    # Auth URLs (for browser-based license acceptance)
    auth_gui_url: str = Field(
        default="https://ux.priorlabs.ai",
        description="PriorLabs login GUI URL.",
    )
    auth_api_url: str = Field(
        default="https://api.priorlabs.ai",
        description="URL for the PriorLabs API (token verification).",
    )

    # Performance/Memory Settings
    allow_cpu_large_dataset: bool = Field(
        default=False,
        description="Allow running TabPFN on CPU with large datasets. "
        "Set to True to override the CPU limitation.",
    )
    mps_memory_fraction: float = Field(
        default=0.7,
        description="Fraction of recommended max MPS memory to allow (0.0 to 2.0). "
        "Used to prevent macOS system crashes on Apple Silicon. "
        "Values > 1.0 are not recommended.",
    )
    max_batched_test_rows: int = Field(
        default=32768,
        ge=0,
        description="Maximum number of test rows fed through the model in a single "
        "forward pass during cached ('fit_with_cache') inference. Larger test sets "
        "are chunked. Performance is close to optimal at the default of 32768. "
        "Set to 0 to disable chunking.",
    )
    max_batched_estimator_rows: int | None = Field(
        default=None,
        ge=0,
        description="Overrides the model's row budget for batching estimators: "
        "estimators whose rows (train plus test, or test only when predicting from "
        "a KV cache) sum to at most this many run as one forward pass; longer "
        "contexts run one estimator at a time. Unset, each architecture applies its "
        "own default. Set to 0 to run every estimator in its own forward pass and "
        "its own cache.",
    )
    max_batched_estimator_cells: int | None = Field(
        default=None,
        ge=0,
        description="Overrides the model's cell budget for batching estimators: "
        "estimators whose cells (rows times prepared columns) sum to at most this "
        "many run as one forward pass. Applies together with the row budget. Unset, "
        "each architecture applies its own default. Set to 0 to run every estimator "
        "in its own forward pass and its own cache.",
    )

    def model_post_init(self, _: Any) -> None:
        """Configure MPS memory limits after settings are initialized.

        To change the memory fraction, set the TABPFN_MPS_MEMORY_FRACTION
        environment variable before importing tabpfn, e.g.:
            export TABPFN_MPS_MEMORY_FRACTION=0.5
        """
        if torch.backends.mps.is_available():
            torch.mps.set_per_process_memory_fraction(self.mps_memory_fraction)


class PytorchSettings(BaseSettings):
    """PyTorch settings for TabPFN."""

    pytorch_cuda_alloc_conf: str = Field(
        default="max_split_size_mb:512",
        description="PyTorch CUDA memory allocation configuration. "
        "Used to optimize GPU memory usage.",
    )


class TestingSettings(BaseSettings):
    """Testing/Development Settings."""

    force_consistency_tests: bool = Field(
        default=False,
        description="Force consistency tests to run regardless of platform. "
        "Set to True to run tests on non-reference platforms.",
    )

    ci: bool = Field(
        default=False,
        description="Indicates if running in continuous integration environment. "
        "Typically set by CI systems (e.g., GitHub Actions).",
    )

    @field_validator("ci", mode="before")
    @classmethod
    def _parse_ci(cls, value: Any) -> bool:
        """Interpret any non-empty environment value as ``True``.

        Some CI providers set the ``CI`` environment variable to a non-boolean
        string (e.g., ``"azure"``).  Treat any non-empty string other than
        common falsy values as ``True`` so importing TabPFN works seamlessly in
        those environments.
        """
        if isinstance(value, str):
            value_lower = value.strip().lower()
            return value_lower not in {"", "0", "false", "no", "off"}
        return bool(value)


class Settings(BaseSettings):
    """Global settings instance."""

    tabpfn: TabPFNSettings = Field(default_factory=TabPFNSettings)
    testing: TestingSettings = Field(default_factory=TestingSettings)
    pytorch: PytorchSettings = Field(default_factory=PytorchSettings)


settings = Settings()
